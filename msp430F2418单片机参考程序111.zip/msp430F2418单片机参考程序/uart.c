//
//               MSP430F21x2
//            -----------------
//        /|\|              XIN|-
//         | |                 |
//         --|RST          XOUT|-
//           |                 |
//       >---|P2.3/A3          |
//       >---|P2.2/A2          |
//       >---|P2.1/A1      P3.1|-->SDA
//       >---|P2.0/A0      P3.2|-->SCL   
//
//                         P3.4|-->TX
//                         P3.5|-->RX
//
// ��λ����ST/r  ->��ʼ    SE/r  ->����
// ��λ����
//******************************************************************************
#include "msp430F2418.h"

#define _nop_() _NOP()
#define uchar unsigned char
#define uint unsigned int
#define ulong unsigned long
#define s32 signed long
#define u32 unsigned long
#define s64 float
#define s8 signed char
#define s16 signed int
#define u16 unsigned int
#define u8 unsigned char
#define chip_busy   0xFFFF



#define lcd1602_read     P5OUT |= 0x02  //R/W
#define lcd1602_write    P5OUT &= 0xFD  
#define lcd1602_dat      P5OUT |= 0x04   //RS
#define lcd1602_com      P5OUT &= 0xFB  
#define lcd1602_e_able   P5OUT |= 0x01   //LCDEN
#define lcd1602_e_unable P5OUT &= 0xFE
#define lcd1602_out      P4DIR = 0xFF;
#define lcd1602_in       P4DIR = 0x00;

#define  range       4096    //29:4096  16g:512
#define  range_data  0x00     //2g:0x00   16g:0x03

#define Busy    0x80 //���ڼ��LCM״̬���е�Busy��ʶ


#define   sda_out    P3DIR |= 0x02     
#define   sda_in     P3DIR &= 0xFD 
#define   sda_up     P3OUT |= 0x02
#define   sda_down   P3OUT &= 0xFD
#define   scl_up     P3OUT |= 0x04
#define   scl_down   P3OUT &= 0xFB

#define  AddWr     0x4C     //д��ַ
#define  AddRd     0x4D    //����ַ

void lcd1602_write_pic(unsigned char add,unsigned char *pic_num);
void lcd1602_write_com(unsigned char com);
void lcd1602_write_dat(unsigned char dat);
void lcd1602_write_character(unsigned char add,unsigned char *p);
void write_zifu(uchar r,uchar l,uchar data);
void write_tubiao(uchar r,uchar l,uchar n);
void lcd1602_init();
void Wr_Com(unsigned char AddWrite,unsigned char DataWrite);

void LCD_X(uchar x, uchar y );
void LCD_Y(uchar x, uchar y );
void LCD_Z(uchar x, uchar y );
void getkey();
void get_gsensor();

void delay(uint k);
void delay_100us(uint k);
uchar flag;

uchar Data[10];
signed int gsensor_X,gsensor_Y,gsensor_Z;

unsigned char pic[10][8]={
{0x04,0x04,0x0E,0x0E,0x1F,0x1F,0x1F,0x00},//��
{0x1F,0x1F,0x1F,0x0E,0x0E,0x04,0x04,0x00},//��
{0x00,0x01,0x03,0x0F,0x1F,0x0F,0x03,0x01},//��
{0x00,0x10,0x18,0x1E,0x1F,0x1E,0x18,0x10},//��
{0x00,0x1F,0x1F,0x1F,0x1F,0x1F,0x1F,0x00},//Z+
{0x00,0x1F,0x11,0x11,0x11,0x11,0x1F,0x00},//Z-
{0x00,0x00,0x14,0x14,0x09,0x14,0x15,0x00},//x:
{0x00,0x00,0x14,0x14,0x1D,0x04,0x1D,0x00},//y:
{0x00,0x00,0x1C,0x04,0x09,0x10,0x1D,0x00},//z:
{0x0E,0x11,0x13,0x15,0x19,0x11,0x0E,0x01}//0.
};

int main(void)
{
  WDTCTL   =  WDTPW + WDTHOLD;       //�ؿ��Ź�
  if (CALBC1_1MHZ==0xFF)					// If calibration constant erased
  {											
    while(1);                               // do not load, trap CPU!!	
  }
  BCSCTL1 = CALBC1_1MHZ;               
  DCOCTL = CALDCO_1MHZ;
 
  UCA0CTL1 =  UCSWRST;       //��λUCSWRSTλ��ʹUARTģ��ļĴ������ڳ�ʼ״̬
  UCA0CTL1 |= UCSSEL1;       //UCLK=SMCLK=1MHz;
  UCA0BR0  = 104;
  UCA0BR1  = 0;
  UCA0MCTL = UCBRS0;         //���ò����� 9600
  P3SEL |= 0x30;                             // P3.4,5 = USCI_A0 TXD/RXD
  UCA0CTL1 &= ~UCSWRST;
  IE2 |= UCA0RXIE;           //�����ж�ʹ��
 
  P3DIR |= 0x06;//IIC
  P2DIR |= 0x03;                            // Set P2 output
  P2OUT |= 0x03;                            // Set display
  //LCD1602���� 
                      
  P5DIR |= 0x07;   //P5
  P4DIR = 0xFF;  //����
  
  P1SEL |= 0x01;
  P1DIR |= 0x01;
  P1OUT |= 0x01;
  P1DIR &= 0xFE;
                 
  lcd1602_out;
  
 
  lcd1602_init();
  flag=1;
 //  _EINT();


/*
 write_zifu(1,8,'A');
 write_zifu(1,9,'B');
 write_zifu(1,10,'C');
 write_zifu(1,11,'D');
 write_zifu(1,12,'1');
 write_zifu(1,13,'2');
 write_zifu(1,14,'3');
 write_zifu(1,15,'4');
 write_zifu(1,16,'5');
lcd1602_write_character(0x80+0x40,"EFGH");
*/

 Wr_Com(0x11,0x1E);
 Wr_Com(0x10,0x05);
 Wr_Com(0x12,0x00);
 Wr_Com(0x0F,range_data);

 
while(1)
{
 // getkey();
   get_gsensor();
  
delay(150);
LCD_X(1,1 );
 LCD_Y(1,10 );
LCD_Z(2,1 );
 
 
    
}
}
void write_tubiao(uchar r,uchar l,uchar n)
{
 
  
  if(r==1)lcd1602_write_com(0x80+l-1);
  if(r==2)lcd1602_write_com(0x80+0x40+l-1);
  lcd1602_write_dat(n-1);
}

void write_zifu(uchar r,uchar l,uchar data)//r=1/2  l=1~8   
{
  if(r==1)lcd1602_write_com(0x80+l-1);
  if(r==2)lcd1602_write_com(0x80+0x40+l-1);
  lcd1602_write_dat(data);
}

void LCD_X(uchar x, uchar y )
{
    signed long temp;
    temp=((float)gsensor_X/range)*1000000;
    write_zifu(x,y,'X');
    if(temp<0){temp=0-temp;write_zifu(x,y+1,'-');
    }  
    else {write_zifu(x,y+1,' ');
    }
    
    write_zifu(x, y+2,((temp/1000000)%10)|0x30); 
    write_zifu(x, y+3,'.');
    write_zifu( x, y+4,((temp/100000)%10)|0x30);
    write_zifu( x, y+5,((temp/10000)%10)|0x30); 
    write_zifu( x,y+6,'g');   
}


void LCD_Y(uchar x, uchar y )
{
    signed long temp;
    temp=((float)gsensor_Y/range)*1000000;
    write_zifu(x,y,'Y');
    if(temp<0){temp=0-temp;write_zifu(x,y+1,'-');
    }  
    else {write_zifu(x,y+1,' ');
    }
    
    write_zifu(x, y+2,((temp/1000000)%10)|0x30); 
    write_zifu(x, y+3,'.');
    write_zifu( x, y+4,((temp/100000)%10)|0x30);
    write_zifu( x, y+5,((temp/10000)%10)|0x30); 
    write_zifu( x,y+6,'g');   
}


void LCD_Z(uchar x, uchar y )
{
    signed long temp;
    temp=((float)gsensor_Z/range)*1000000;
    write_zifu(x,y,'Z');
    if(temp<0){temp=0-temp;write_zifu(x,y+1,'-');
    }  
    else {write_zifu(x,y+1,' ');
    }
    
    write_zifu(x, y+2,((temp/1000000)%10)|0x30); 
    write_zifu(x, y+3,'.');
    write_zifu( x, y+4,((temp/100000)%10)|0x30);
    write_zifu( x, y+5,((temp/10000)%10)|0x30); 
    write_zifu( x,y+6,'g');   
}

/*

 #pragma vector=USCIAB0RX_VECTOR
  __interrupt void USCI0RX_ISR(void)
{
  
  if(flag_uart==0)
  {
    rx_temp=UCA0RXBUF;   
    if(rx_temp=='S')
    {
      
      rx_buf[0]=rx_temp;
      flag_uart=0;
      rx_cnt_uart++;
      
    }
    else
    {
      rx_buf[rx_cnt_uart]=rx_temp;
      flag_uart=0;
      rx_cnt_uart++;
    }
    if(rx_temp=='A')		//���ڷ��͹�����������0x0d��β
    {
      
       flag_uart=1;
       rx_cnt_uart=0;
       if(rx_buf[1]=='T')
       {
         flag_start=1;
        
       }
   
  }
   IFG2 &= ~UCA0RXIFG;          
}

*/

void   uart_tx (uchar Output)
{
  
  while (!(IFG2&UCA0TXIFG));
  UCA0TXBUF=Output;     
}

void   uart_tx_uint (uint Output)
{
  uint temp;
  temp=Output>>8;
  uart_tx(temp);
  temp=Output;
  uart_tx(temp);
  
}


void delay_100us(uint k)//****************��ʱ0.1*Kms********
{
  uchar i,j;
  for(i=0;i<k;i++)
  for(j=0;j<225;j++);
}



uchar asc_string(uchar a)	//��ASCALL��ת�����ַ�
{
  uchar result;
  if((a>0x30||a==0x30)&&a<0x40)  result=a&0x0F; 
 else if((a>0x40&&a<0x47)||(a>0x60&&a<0x67))
  {
        if(a==0x41||a==0x61)result=0x0A;
        else if(a==0x42||a==0x62)result=0x0B;
	else if(a==0x43||a==0x63)result=0x0C;
	else if(a==0x44||a==0x64)result=0x0D;
	else if(a==0x45||a==0x65)result=0x0E;
	else if(a==0x46||a==0x66)result=0x0F;
  }
  else result=0x00;
  return result;
}

unsigned char lcd1602_read_dat()
{
unsigned char dat;
lcd1602_in;
lcd1602_read;
lcd1602_dat;
lcd1602_e_able;
dat=P4IN;
lcd1602_e_unable;
lcd1602_out;
return dat;
}

void read_busy()
{
while(lcd1602_read_dat()&0x80);
}


void lcd1602_write_dat(unsigned char dat)
{
uint i;

lcd1602_dat;
lcd1602_write;
lcd1602_e_unable;

P4OUT = dat;
for(i=0;i<300;i++)  //140us
_nop_();
lcd1602_e_able;

for(i=0;i<300;i++)  //450us
_nop_();
lcd1602_e_unable;
//read_busy();
}

void lcd1602_write_com(unsigned char com)
{
uint i;

lcd1602_com;
lcd1602_write;
lcd1602_e_unable;
P4OUT = com;
for(i=0;i<300;i++)
_nop_();
lcd1602_e_able;
for(i=0;i<300;i++)
_nop_();
lcd1602_e_unable;
//read_busy();
}


//��ʼ��
void lcd1602_init()
{
read_busy();
lcd1602_write_com(0x38);//����8λ��ʽ��2�У�5x7
lcd1602_write_com(0x08);
lcd1602_write_com(0x01);//�����Ļ��ʾ
lcd1602_write_com(0x06);//�趨���뷽ʽ����������λ
lcd1602_write_com(0x0c);//������ʾ���ع�꣬����˸
}

//��ʾ�ַ���
void lcd1602_write_character(unsigned char add,unsigned char *p)
{
lcd1602_write_com(add++);
while (*p!='\0')
{
lcd1602_write_dat(*p++);
}
}


//���Զ����ַ�д��CGRAM
//add��CGRAM �ĵ�ַ��0~7��
//*pic_num��ָ��һ��8λ������׵�ַ
void lcd1602_write_pic(unsigned char add,unsigned char *pic_num)
{
unsigned char i;
add=add<<3;
for(i=0;i<8;i++)
{
lcd1602_write_com(0x40|add+i);
lcd1602_write_dat(*pic_num++);
}
}



void lcd1602_flag0()
{
  lcd1602_write_character(0x80,"X:");
  lcd1602_write_character(0x80+0x40,"Y:");
  lcd1602_write_character(0x80+0x40+8,"Z:");
}

void lcd1602_flag1()
{
  for(uchar i=0;i<4;i++)
  lcd1602_write_pic(i,pic[i]);
}

//5ms��ʱ
void Delay5Ms(void)
{
 unsigned int TempCyc = 5552;
 while(TempCyc--);
}
//400ms��ʱ
void Delay400Ms(void)
{
 unsigned char TempCycA = 5;
 unsigned int TempCycB;
 while(TempCycA--)
 {
  TempCycB=7269;
  while(TempCycB--);
 };

}

void _nop_()
{
   _NOP();_NOP();_NOP(); _NOP();_NOP();_NOP(); _NOP();_NOP();
   _NOP(); _NOP();_NOP();_NOP(); _NOP();_NOP();_NOP(); _NOP();
   _NOP();_NOP();
}


void Start(void)
  {
    
   sda_out;
   
   sda_up;
  
   scl_up;
   _nop_();_nop_();_nop_();_nop_();_nop_();
   sda_down;
   _nop_();_nop_();_nop_();_nop_();_nop_();
   scl_down;
   _nop_();_nop_();_nop_();_nop_();_nop_();
  }


 void Stop(void)
  {
   sda_out;
   sda_down;
   _nop_();_nop_();_nop_();
   scl_up;
   _nop_();_nop_();_nop_();
   sda_up;
   _nop_();_nop_();_nop_();_nop_();_nop_();
  
   
   }


uchar respons()  //����Ӧ���ź�***********************ǰ����send����*******************
{
        unsigned long i;
	uchar temp;
        sda_in;
        i=0;
    
	scl_up;
	_nop_();_nop_();
	while((P3IN&0x02)&&(i<10))i++;
	scl_down;
        _nop_();
         sda_out;
         sda_up;
	_nop_();_nop_();_nop_();_nop_();
        sda_down;
        if(i<10)temp=0xA5;    //����ȷӦ��
        else     temp=0xFF;   //Ӧ��ʱ
       
       
      
      
        return  temp;
}

//Ӧ�� IIC����  SDA�͵�ƽ
   void Ack()
   {
        sda_out;
        
        sda_down;
	_nop_();_nop_();_nop_();
	scl_up;
	_nop_();_nop_();_nop_();_nop_();_nop_();
	scl_down;
	_nop_();_nop_();
        
       
     }

//��Ӧ�� IIC����   SDA�ߵ�ƽ
	void NoAck(void)
	{
         sda_out;
          
	 sda_up;
	 _nop_();_nop_();_nop_();
	 scl_up;
	 _nop_();_nop_();_nop_();_nop_();_nop_();
	 scl_down;
	 _nop_();_nop_();
 
	 }

//����һ���ֽ�
	 void Send(unsigned char Data)
	 { 
	  unsigned char BitCounter=8;
	  unsigned char temp;
          sda_out;

	  do
	    {
		 temp=Data;
		 
		
		 if((temp&0x80)==0x80)
		    sda_up;
		 else
		    sda_down;

                  _nop_();
                  scl_up;
                  _nop_();_nop_();_nop_();_nop_();
			scl_down;
                        _nop_();_nop_();_nop_();_nop_();
			temp=Data<<1;
			Data=temp;
			BitCounter--;
		  }
	  while(BitCounter);
	    //  scl_up;
             
              sda_down;
              _nop_();_nop_();_nop_();
	  }


  uchar Read(void)
	  {
	   unsigned char temp=0;
	  
	   unsigned char BitCounter=8;
           sda_out;
          
	   sda_down;
           scl_down;
          sda_in;
           
            _nop_();_nop_();_nop_();_nop_();_nop_();
	   do
	     {
		  
		  scl_up;
		  _nop_();_nop_();_nop_();_nop_();_nop_();
		  if(P3IN&0x02)
		     temp=temp|0x01;
		  else
		     temp=temp&0xfe;
                  
		  if(BitCounter-1)
		     {
			  temp=temp<<1; 
                          
			  }
			  BitCounter--;
                   scl_down;
		  _nop_();_nop_();_nop_();_nop_();_nop_();
			 }
		while(BitCounter);
       
		return temp;
                 
	  }


void Wr_Com(unsigned char AddWrite,unsigned char DataWrite)
{  
	 Start();
	 Send(AddWr);//������ַ
	 flag=respons(); 
         Send(AddWrite);//д���ݵ�ַ
         flag=respons();
         Send(DataWrite);//����
         flag=respons();
	 Stop();
	 delay(100);
}

void Rd_Com(unsigned char AddRead,unsigned char Num)
	  {
	   unsigned char i;
	
           Start();
           Send(AddWr);//Write Address
           flag=respons();
           Send(AddRead);//Ҫ���ĵ�ַ
           flag=respons();
           
           Start();
           Send(AddRd);//Write Address
           flag=respons();
           for(i=0;i<Num-1;i++)//һ�ζ�������
	      {	                
		 Data[i]=Read();//Read Data
                 Ack();
	      }  
           Data[Num-1]=Read();//Read Data
         
	  NoAck();
	  Stop();
	  }

void delay(uint k)//****************��ʱ0.1*Kms*******************************************************************
{
  uint i,j;
  for(i=0;i<k;i++)
  for(j=0;j<225;j++);
}


void getkey()
{
  if((P1IN&0x01))
  {
    delay(400);
    if((P1IN&0x01))
    {
       delay(400);
      if((P1IN&0x01)){           //����λ������
        {
          lcd1602_write_com(0x01);//�����Ļ��ʾ
          if(flag==0){flag=1;lcd1602_flag1();}
          else if(flag==1){flag=0;lcd1602_flag0();}
        }
    }
    }
  } 
}


void get_gsensor()
{

  Rd_Com(0x02,6);
  
  gsensor_X = (Data[0]+Data[1]*256)/4;
  gsensor_Y = (Data[2]+Data[3]*256)/4;
  gsensor_Z = (Data[4]+Data[5]*256)/4;
  if(gsensor_X>8500)gsensor_X=8500;
  if(gsensor_Y>8500)gsensor_Y=8500;
  if(gsensor_Z>8500)gsensor_Z=8500;
  if(gsensor_X>8192)gsensor_X = gsensor_X-16384;
  if(gsensor_Y>8192)gsensor_Y = gsensor_Y-16384;
  if(gsensor_Z>8192)gsensor_Z = gsensor_Z-16384;

}